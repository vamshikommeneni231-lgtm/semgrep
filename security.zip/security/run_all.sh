#!/bin/bash
echo "🔐 Starting Full Security Scan (SAST + DAST)..."

bash "$(dirname "$0")/sast/run_semgrep.sh"
bash "$(dirname "$0")/dast/run_zap.sh"

echo "🧾 All reports generated under security/reports/"
