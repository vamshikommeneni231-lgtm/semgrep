#!/usr/bin/env python3
import json, html, sys, os

input_file = sys.argv[1] if len(sys.argv) > 1 else "reports/semgrep.json"
output_file = sys.argv[2] if len(sys.argv) > 2 else "reports/semgrep_report.html"

if not os.path.exists(input_file):
    print(f"❌ Input file not found: {input_file}")
    sys.exit(1)

with open(input_file, "r") as f:
    data = json.load(f)

results = data.get("results", [])

html_content = f"""
<html>
<head>
    <meta charset="UTF-8">
    <title>Semgrep SAST Report</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            background: #fafafa;
            color: #333;
            margin: 20px;
        }}
        h1 {{
            background: #0047ab;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }}
        th, td {{
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }}
        th {{
            background: #f0f0f0;
        }}
        tr:nth-child(even) {{ background: #f9f9f9; }}
        .ERROR {{ color: red; font-weight: bold; }}
        .WARNING {{ color: orange; }}
        .INFO {{ color: green; }}
        .summary {{
            background: #e8f0ff;
            padding: 10px;
            border-left: 5px solid #0047ab;
            margin-bottom: 10px;
        }}
    </style>
</head>
<body>
<h1>Semgrep SAST Report</h1>
<div class="summary">
    <strong>Total Findings:</strong> {len(results)}<br>
    <strong>Semgrep Version:</strong> {data.get("version", "N/A")}
</div>

<table>
<tr>
    <th>#</th>
    <th>Rule ID</th>
    <th>Message</th>
    <th>Severity</th>
    <th>File</th>
    <th>Line</th>
    <th>CWE</th>
</tr>
"""

for i, r in enumerate(results, start=1):
    rule_id = r.get("check_id", "")
    msg = html.escape(r.get("extra", {}).get("message", ""))
    sev = r.get("extra", {}).get("severity", "INFO").upper()
    path = r.get("path", "")
    line = r.get("start", {}).get("line", "")
    cwe = r.get("extra", {}).get("metadata", {}).get("cwe", "")
    html_content += f"""
<tr>
    <td>{i}</td>
    <td>{rule_id}</td>
    <td>{msg}</td>
    <td class="{sev}">{sev}</td>
    <td>{path}</td>
    <td>{line}</td>
    <td>{cwe}</td>
</tr>
"""

html_content += """
</table>
</body>
</html>
"""

os.makedirs(os.path.dirname(output_file), exist_ok=True)
with open(output_file, "w", encoding="utf-8") as f:
    f.write(html_content)

print(f"✅ HTML SAST report generated: {output_file}")
