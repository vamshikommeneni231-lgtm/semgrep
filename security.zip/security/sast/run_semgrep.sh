#!/usr/bin/env bash
set -euo pipefail

# ---------------------------------------------------------------------------
# 🔧 Setup and directory structure
# ---------------------------------------------------------------------------
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPORT_DIR="$ROOT_DIR/reports"
mkdir -p "$REPORT_DIR"

echo "🔍 Starting full local security scan..."
echo "📁 Reports directory: $REPORT_DIR"
echo

# ---------------------------------------------------------------------------
# 🧠 [1/6] SEMGREP (SAST)
# ---------------------------------------------------------------------------
echo "🧠 [1/6] Semgrep (SAST)"
export SEMGREP_SEND_METRICS=off
export PATH="$PATH:$HOME/.local/bin"

# ✅ Dynamically find semgrep_rules folder
SEMGREP_RULE_DIR="$(cd "$ROOT_DIR" && find . -type d -name semgrep_rules | head -n 1 || true)"

if [ -z "$SEMGREP_RULE_DIR" ]; then
  echo "❌ semgrep_rules directory not found anywhere under $ROOT_DIR!"
  echo "Make sure your rules folder exists at: security/semgrep_rules/"
  exit 1
fi

# Convert relative to absolute path
SEMGREP_RULE_DIR="$(cd "$ROOT_DIR/$SEMGREP_RULE_DIR" && pwd)"
echo "📂 Using Semgrep rules from: $SEMGREP_RULE_DIR"

# Run Semgrep scan (JSON output)
semgrep scan \
  --config=p/security-audit \
  --config=p/owasp-top-ten \
  --config=p/secrets \
  --config="$SEMGREP_RULE_DIR" \
  --config=r/all \
  --json --output "$REPORT_DIR/semgrep.json" --timeout 300 || true

# Generate HTML report (proper syntax)
semgrep report --json "$REPORT_DIR/semgrep.json" --html --output "$REPORT_DIR/semgrep.html" || true
echo "📄 Semgrep HTML report: $REPORT_DIR/semgrep.html"
echo

# ---------------------------------------------------------------------------
# 📦 [2/6] TRIVY (SCA)
# ---------------------------------------------------------------------------
echo "📦 [2/6] Trivy (Dependencies)"
SCAN_PATH="$(pwd)"
# ✅ Modern Trivy syntax (no deprecated flags)
trivy fs --scanners vuln,misconfig --skip-db-update --format html \
  --output "$REPORT_DIR/trivy.html" "$SCAN_PATH" || true
echo "📄 Trivy HTML report: $REPORT_DIR/trivy.html"
echo

# ---------------------------------------------------------------------------
# 🧩 [3/6] OWASP DEPENDENCY-CHECK (Java)
# ---------------------------------------------------------------------------
echo "🧩 [3/6] OWASP Dependency-Check (Java)"
if [[ -f "pom.xml" || -f "build.gradle" ]]; then
  if command -v docker &> /dev/null; then
    docker run --rm -v "$(pwd)":/src -v "$REPORT_DIR":/report \
      owasp/dependency-check:latest --project "LocalScan" --scan /src \
      --format HTML --out /report --disableAssembly || true
    echo "📄 Dependency-Check HTML report: $REPORT_DIR/dependency-check-report.html"
  else
    echo "⚠️ Docker not found — skipping Dependency-Check (requires Docker)."
  fi
else
  echo "⚡ No Maven/Gradle project detected — skipping Dependency-Check."
fi
echo

# ---------------------------------------------------------------------------
# 🏗️ [4/6] CHECKOV (IaC)
# ---------------------------------------------------------------------------
echo "🏗️ [4/6] Checkov (Terraform/K8s)"
if find . -type f \( -name "*.tf" -o -name "*.yaml" -o -name "*.yml" \) | grep -q .; then
  checkov -d . --quiet --output cli > "$REPORT_DIR/checkov.html" || true
  echo "📄 Checkov HTML report: $REPORT_DIR/checkov.html"
else
  echo "⚡ No Terraform/K8s files found — skipping Checkov."
fi
echo

# ---------------------------------------------------------------------------
# 🔐 [5/6] DETECT-SECRETS (Secrets Scan)
# ---------------------------------------------------------------------------
echo "🔐 [5/6] detect-secrets (Secrets scan)"
detect-secrets scan > "$REPORT_DIR/detect_secrets.txt" || true
echo "📄 Secrets scan output: $REPORT_DIR/detect_secrets.txt"
echo

# ---------------------------------------------------------------------------
# ⚙️ [6/6] TFSEC (Terraform)
# ---------------------------------------------------------------------------
echo "⚙️ [6/6] tfsec (Terraform)"
if find . -type f -name "*.tf" | grep -q .; then
  tfsec . --soft-fail --format html > "$REPORT_DIR/tfsec.html" || true
  echo "📄 tfsec HTML report: $REPORT_DIR/tfsec.html"
else
  echo "⚡ No Terraform files — skipping tfsec."
fi
echo

# ---------------------------------------------------------------------------
# 🪲 OPTIONAL: SPOTBUGS (Java bytecode)
# ---------------------------------------------------------------------------
if [ -d target ]; then
  echo "🪲 SpotBugs + FindSecBugs"
  if command -v docker &> /dev/null; then
    docker run --rm -v "$(pwd)":/src spotbugs/spotbugs:latest \
      -textui /src/target/*.jar > "$REPORT_DIR/spotbugs.txt" 2>/dev/null || true
    echo "📄 SpotBugs output: $REPORT_DIR/spotbugs.txt"
  else
    echo "⚠️ Docker not found — skipping SpotBugs scan."
  fi
else
  echo "⚡ No JARs found — skipping SpotBugs."
fi
echo

# ---------------------------------------------------------------------------
# 📊 Convert Semgrep JSON → HTML (SAST Report)
# ---------------------------------------------------------------------------
echo "📊 Generating Semgrep HTML SAST Report..."
if [ -f "$ROOT_DIR/convert_semgrep_to_html.py" ]; then
  python3 "$ROOT_DIR/convert_semgrep_to_html.py" \
    "$REPORT_DIR/semgrep.json" "$REPORT_DIR/semgrep_report.html" || true
  echo "📄 Semgrep SAST HTML report generated at: $REPORT_DIR/semgrep_report.html"
else
  echo "⚠️  Skipping Semgrep HTML conversion — script not found at: $ROOT_DIR/convert_semgrep_to_html.py"
fi
echo


# ---------------------------------------------------------------------------
# 🏁 FINAL SUMMARY
# ---------------------------------------------------------------------------
echo "✅ Security scan completed successfully!"
echo "📂 All reports are available in: $REPORT_DIR"
echo
echo "💡 To open in Windows:"
echo "   explorer.exe $REPORT_DIR"
echo
echo "💡 To open in Linux desktop:"
echo "   xdg-open $REPORT_DIR"
echo
