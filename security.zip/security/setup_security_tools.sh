#!/bin/bash
set -e
echo "🔧 Setting up Local Security Tools (SAST + DAST) without sudo..."

BASE_DIR="$(dirname "$0")"
mkdir -p "$BASE_DIR/reports"

# --- Semgrep Setup ---
if ! command -v semgrep &> /dev/null; then
  echo "📦 Installing Semgrep locally..."
  python -m ensurepip --upgrade || true
  python -m pip install --user semgrep
  export PATH="$PATH:$HOME/AppData/Roaming/Python/Python311/Scripts"
else
  echo "✅ Semgrep already installed"
fi

# --- Docker Check ---
if ! command -v docker &> /dev/null; then
  echo "❌ Docker not found. Please install Docker Desktop manually:"
  echo "👉 https://www.docker.com/products/docker-desktop/"
  exit 1
else
  echo "✅ Docker available"
fi

# --- Pull ZAP Image ---
if [[ "$(docker images -q owasp/zap2docker-stable 2> /dev/null)" == "" ]]; then
  echo "⬇️ Pulling OWASP ZAP Docker image..."
  docker pull owasp/zap2docker-stable
else
  echo "✅ OWASP ZAP image already available"
fi

echo "🎯 Setup complete! You can now run: bash security/run_all.sh"
