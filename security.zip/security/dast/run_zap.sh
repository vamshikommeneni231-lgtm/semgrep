#!/bin/bash
echo "⚔️ Running OWASP ZAP DAST Scan..."
cd "$(dirname "$0")"

TARGET_URL="http://localhost:8080"
REPORT_DIR="../reports"
mkdir -p "$REPORT_DIR"

docker run --rm -v "$(pwd)/$REPORT_DIR:/zap/wrk" -t owasp/zap2docker-stable zap-baseline.py \
  -t "$TARGET_URL" -r zap_report.html -J zap_report.json

echo "✅ ZAP scan completed. Reports saved to security/reports/"
